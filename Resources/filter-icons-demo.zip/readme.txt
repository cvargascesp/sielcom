The following icon sets contain "filter" icons:

http://www.vista-style-icons.com/libs/large-vista/filter.htm
http://www.vista-style-icons.com/libs/large-vista-icons.htm
http://www.vista-style-icons.com/libs/vista-toolbar/filter.htm
http://www.vista-style-icons.com/libs/vista-toolbar-icons.htm
http://www.777icons.com/libs/blue-icons.htm
http://www.777icons.com/libs/db-soft/filter.htm
http://www.777icons.com/libs/database-software-icons.htm
http://www.777icons.com/libs/stock-toolbar/filter.htm
http://www.777icons.com/libs/stock-toolbar-icons.htm
http://www.777icons.com/libs/biz-soft/filter.htm
http://www.777icons.com/libs/business-software-icons.htm
http://www.777icons.com/libs/artistic-toolbar-icons.htm
http://www.777icons.com/libs/db/filter.htm
http://www.777icons.com/libs/database-icons.htm
http://www.777icons.com/libs/fire-toolbar/filter.htm
http://www.777icons.com/libs/fire-toolbar-icons.htm
http://www.777icons.com/libs/design/filter.htm
http://www.777icons.com/libs/design-icons.htm
http://www.777icons.com/libs/gr/filter.htm
http://www.777icons.com/libs/graphic-icons.htm
http://www.777icons.com/libs/med/filter.htm
http://www.777icons.com/libs/medical-icons.htm
http://www.777icons.com/libs/sci/filter.htm
http://www.777icons.com/libs/science-icons.htm
http://www.777icons.com/libs/e-mail/filter.htm
http://www.777icons.com/libs/e-mail-icons.htm
http://www.777icons.com/libs/toolbar/filter.htm
http://www.777icons.com/libs/toolbar-icons.htm
http://www.777icons.com/libs/large-vista/filter.htm
http://www.777icons.com/libs/large-vista-icons.htm
http://www.777icons.com/libs/vista-toolbar/filter.htm
http://www.777icons.com/libs/vista-toolbar-icons.htm
http://www.vista-style-icons.com/libs/large-vista/filters.htm
http://www.777icons.com/libs/large-vista/filters.htm
http://www.777icons.com/libs/db/data_filter.htm
http://www.777icons.com/libs/design/color_filter.htm
http://www.777icons.com/libs/gr/color_filter.htm
http://www.777icons.com/libs/e-mail/spam_filter.htm
http://www.777icons.com/libs/sec/spam-filter.htm
http://www.777icons.com/libs/security-icons.htm
http://www.777icons.com/libs/e-mail/spam-filter.htm
http://www.777icons.com/libs/db/data_filters.htm
http://www.777icons.com/libs/e-mail/spam_filters.htm

Full list: 
http://www.iconempire.com/find/filter-icons.htm


You can purchase individual icons or entire icon sets at http://www.perfect-icons.com/